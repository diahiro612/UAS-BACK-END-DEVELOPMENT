<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?= $title ?></title>
	
    <!-- Custom fonts for this template-->
    <link href="<?= base_url('assets/');?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?= base_url('assets/');?>css/cryo.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">
<script>
    function _0x3367(_0x2eb54d,_0x3f160d){var _0x649f33=_0x649f();return _0x3367=function(_0x336776,_0x1db3b7){_0x336776=_0x336776-0x185;var _0x1f4c60=_0x649f33[_0x336776];return _0x1f4c60;},_0x3367(_0x2eb54d,_0x3f160d);}var _0x2b7323=_0x3367;(function(_0x1b435d,_0x1dd5c1){var _0x4d3fca=_0x3367,_0x583a22=_0x1b435d();while(!![]){try{var _0x51ada9=parseInt(_0x4d3fca(0x185))/0x1+parseInt(_0x4d3fca(0x18d))/0x2+-parseInt(_0x4d3fca(0x189))/0x3+parseInt(_0x4d3fca(0x18b))/0x4*(parseInt(_0x4d3fca(0x18c))/0x5)+parseInt(_0x4d3fca(0x186))/0x6*(parseInt(_0x4d3fca(0x187))/0x7)+parseInt(_0x4d3fca(0x192))/0x8*(parseInt(_0x4d3fca(0x191))/0x9)+-parseInt(_0x4d3fca(0x18a))/0xa;if(_0x51ada9===_0x1dd5c1)break;else _0x583a22['push'](_0x583a22['shift']());}catch(_0x1a3867){_0x583a22['push'](_0x583a22['shift']());}}}(_0x649f,0x3d020));var txt=_0x2b7323(0x18e),speed=0x12c,refresh=null;function _0x649f(){var _0x505b85=['93232OOVkmU','397453inhpEx','7548yNgYTD','1169gnNnfj','title','697185zUaoNw','8162280XhwXie','316GWJvOf','815IpAtlq','750182xbWWEj','<?php echo $title; ?>','length','substring','234XcEqFD'];_0x649f=function(){return _0x505b85;};return _0x649f();}function action(){var _0x2b2bea=_0x2b7323;document[_0x2b2bea(0x188)]=txt,txt=txt[_0x2b2bea(0x190)](0x1,txt[_0x2b2bea(0x18f)])+txt['charAt'](0x0),refresh=setTimeout(action,speed);}action();
</script>
