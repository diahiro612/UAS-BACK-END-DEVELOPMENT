<?php
// Data Mahasiswa (Simulasi dari database)
$data = [
    ['id' => 1, 'nama' => 'Andi', 'matkul' => 'Matematika', 'nilai' => 85],
    ['id' => 2, 'nama' => 'Budi', 'matkul' => 'Fisika', 'nilai' => 90],
    ['id' => 3, 'nama' => 'Citra', 'matkul' => 'Kimia', 'nilai' => 88],
];

// Handle delete
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $data = array_filter($data, function ($item) use ($id) {
        return $item['id'] != $id;
    });
}

// Handle edit
$editData = null;
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    foreach ($data as $row) {
        if ($row['id'] == $_GET['id']) {
            $editData = $row;
            break;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $matkul = $_POST['matkul'];
    $nilai = $_POST['nilai'];

    foreach ($data as &$row) {
        if ($row['id'] == $id) {
            $row['nama'] = $nama;
            $row['matkul'] = $matkul;
            $row['nilai'] = $nilai;
            break;
        }
    }
    unset($row);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Rekapitulasi Nilai Mahasiswa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #2c3e50;
            color: white;
            position: fixed;
            padding: 20px;
        }
        .sidebar h2 {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 30px;
        }
        .sidebar h2 img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            padding: 10px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: block;
        }
        .sidebar ul li a:hover {
            background-color: #34495e;
            padding-left: 10px;
        }
        .main-content {
            margin-left: 270px;
            padding: 20px;
        }
        .main-content h1 {
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #2c3e50;
            color: white;
        }
        .action-buttons a {
            text-decoration: none;
            padding: 5px 10px;
            margin-right: 5px;
            color: white;
            border-radius: 3px;
        }
        .edit {
            background-color: #3498db;
        }
        .delete {
            background-color: #e74c3c;
        }
        .logout {
            display: inline-block;
            margin-top: 10px;
            background-color: #e74c3c;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 3px;
        }
        .form-container {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .form-container input, .form-container button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>
            <img src="http://amikom.ac.id/public/docs/2016/logo_amikom_full_color.png" alt="Logo"> AMIKOM
        </h2>
        <ul>
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Data Mahasiswa</a></li>
            <li><a href="#">Rekap Nilai</a></li>
            <li><a href="<?= base_url('auth/logout')?>">Logout</a></li>
        </ul>
    </div>
    <div class="main-content">
        <h1>Rekapitulasi Nilai Mahasiswa</h1>

        <?php if ($editData): ?>
            <div class="form-container">
            <form method="post">
    <input type="hidden" name="id" value="<?= htmlspecialchars($editData['id']) ?>">
    <input type="text" name="nama" placeholder="Nama Mahasiswa" value="<?= htmlspecialchars($editData['nama']) ?>" required>
    <input type="text" name="matkul" placeholder="Mata Kuliah" value="<?= htmlspecialchars($editData['matkul']) ?>" required>
    <input type="number" name="nilai" placeholder="Nilai" value="<?= htmlspecialchars($editData['nilai']) ?>" required>
    <button type="submit" name="save">Simpan</button>
</form>

            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Mahasiswa</th>
                        <th>Mata Kuliah</th>
                        <th>Nilai</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data as $index => $row): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td><?= $row['nama'] ?></td>
                            <td><?= $row['matkul'] ?></td>
                            <td><?= $row['nilai'] ?></td>
                            <td class="action-buttons">
                                <a href="?action=edit&id=<?= $row['id'] ?>" class="edit">Edit</a>
                                <a href="?action=delete&id=<?= $row['id'] ?>" class="delete" onclick="return confirm('Apakah Anda yakin?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>
