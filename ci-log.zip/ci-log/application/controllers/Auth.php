<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
	}
	public function index()
	{	
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');

		if( $this->form_validation->run() == false) {
			$data['title'] = 'Diahiro Apps Login | ';
			$this->load->view('templates/auth_header', $data);
			$this->load->view('auth/login');
			$this->load->view('templates/auth_footer');
		}else {
			$this->__login();
		}
	}

	private function __login()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$user = $this->db->get_where('user', ['email' => $email])->row_array();
		
		if($user) {
			if($user['is_active'] == 1) {
				if(password_verify($password, $user['password'])) {
					$data = [
						'email' => $user['email'],
						'role_id' => $user['role_id']
					];
					$this->session->set_userdata($data);
					redirect('dashboard');
				} else {
					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Wrong password/Email.</div>');
					redirect('auth');
				}
			} else {
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email/Account not yet active.</div>');
				redirect('auth');
			}
		} else {
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email not registered.</div>');
				redirect('auth');
		}
	}

	public function registration() 
	{

		$this->form_validation->set_rules('name','Name','required|trim');
		$this->form_validation->set_rules('email','Email','required|trim|valid_email|is_unique[user.email]',['is_unique' => 'Email already registered']);
		$this->form_validation->set_rules('password1','Password','required|trim|min_length[3]|matches[password2]', ['min_length' => 'Password too short']);
		$this->form_validation->set_rules('password2','Password','required|trim|min_length[3]|matches[password1]',['matches' => 'Password not match!', 'min_length' => 'Password too short']);

		if( $this->form_validation->run() == false) {
			
			$data['title'] = 'Diahiro Apps Registration | ';
			$this->load->view('templates/auth_header', $data);
			$this->load->view('auth/registration');
			$this->load->view('templates/auth_footer');
		} else {
			$data = [
				'name' => htmlspecialchars($this->input->post('name', TRUE)),
				'email' => htmlspecialchars($this->input->post('email', TRUE)),
				'image' => 'default.webp',
				'password' => password_hash($this->input->post('password2'), PASSWORD_DEFAULT),
				'role_id' => 2,
				'is_active' => 1,
				'date_created' => time()
			];
				$this->db->insert('user',$data);
				$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Congratulations! Successful registration.</div>');
				redirect('auth');
		}
	}

	public function logout()
	{
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('role_id');
		$this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">You have been logged out!</div>');
		redirect('auth');
	}
}

class FormHelper {

	public function __customCss() {
		echo "<style>
		.error-message {
    	color: crimson;
    	margin-left: 21px;
    	margin-top: 5px;
    	border-radius: 21px;}
		</style>";
	}
}
